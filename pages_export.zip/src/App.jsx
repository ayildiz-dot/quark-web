import { useState, useEffect, createContext, useContext } from 'react'
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from './lib/supabase'
import Navbar from './components/Navbar'
import ScrollToTopButton from './components/ScrollToTopButton'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import DashboardHome from './pages/DashboardHome'
import ScorecardDashboard from './pages/ScorecardDashboard'
import Evaluations from './pages/Evaluations'
import Admin from './pages/Admin'
import ScorecardBuilder from './pages/ScorecardBuilder'
import EvaluationForm from './pages/EvaluationForm'
import ScorecardHistory from './pages/ScorecardHistory'
import ResetPassword from './pages/ResetPassword'
import { usePresence } from './hooks/usePresence'
import DuckLoader from './components/DuckLoader'
import Calibration from './pages/Calibration'
import Coaching from './pages/Coaching'

export const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

function UnsavedModal({ show, onLeave, onStay }) {
  if (!show) return null
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
    }}>
      <div className="card" style={{ maxWidth: 420, width: '100%', padding: 32 }}>
        <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 12 }}>⚠️ Unsaved Changes</div>
        <p style={{ color: 'var(--text-secondary)', marginBottom: 24, lineHeight: 1.6 }}>
          You have unsaved changes on this scorecard. If you leave now, your changes will be lost.
        </p>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="btn btn-danger" onClick={onLeave}>Leave without saving</button>
          <button className="btn btn-primary" onClick={onStay}>Stay on page</button>
        </div>
      </div>
    </div>
  )
}

function AppShell({ user, profile, logout, fetchProfile }) {
  const navigate = useNavigate()
  const location = useLocation()
  const [unsavedChanges, setUnsavedChanges] = useState(false)
  const [showNavModal, setShowNavModal] = useState(false)
  const [pendingNavPath, setPendingNavPath] = useState(null)

  usePresence(user)

  const isAdminOrOwner = ['admin', 'owner'].includes(profile?.role)
  const isKgUser = profile?.email?.endsWith('@kaizengaming.com')

  const handleLeave = () => {
    setUnsavedChanges(false)
    setShowNavModal(false)
    const dest = pendingNavPath
    setPendingNavPath(null)
    if (dest === -1) {
      // Go back twice: once to undo our dummy pushState, once to actually leave
      navigate(-1)
      setTimeout(() => navigate(-1), 50)
    } else if (dest) navigate(dest)
  }

  const handleStay = () => {
    setShowNavModal(false)
    setPendingNavPath(null)
  }

  const safeNavigate = (path) => {
    if (unsavedChanges) {
      setPendingNavPath(path)
      setShowNavModal(true)
    } else {
      navigate(path)
    }
  }

  return (
    <AuthContext.Provider value={{
      user, profile, logout,
      refreshProfile: () => fetchProfile(user),
      unsavedChanges, setUnsavedChanges,
      showNavModal, setShowNavModal,
      pendingNavPath, setPendingNavPath,
      safeNavigate
    }}>
      <div className="app-shell">
        <UnsavedModal show={showNavModal} onLeave={handleLeave} onStay={handleStay} />
        <Navbar />
        <main className="main-content">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            >
              <Routes location={location}>
                <Route path="/" element={<Navigate to="/evaluations" replace />} />
                <Route path="/dashboard" element={<DashboardHome />} />
                <Route path="/dashboard/:division" element={<DashboardHome />} />
                <Route path="/dashboard/:division/:scorecardId" element={<ScorecardDashboard />} />
                <Route path="/evaluations" element={<Evaluations />} />
                <Route path="/evaluations/new" element={<EvaluationForm />} />
                <Route path="/scorecards/:id/edit" element={isAdminOrOwner ? <ScorecardBuilder /> : <Navigate to="/dashboard" replace />} />
                <Route path="/scorecards/:id/history" element={isAdminOrOwner ? <ScorecardHistory /> : <Navigate to="/dashboard" replace />} />
                <Route path="/admin" element={isAdminOrOwner ? <Admin /> : <Navigate to="/dashboard" replace />} />
                <Route path="/calibration" element={isKgUser && ['owner','admin','evaluator'].includes(profile?.role) ? <Calibration /> : <Navigate to="/dashboard" replace />} />
                <Route path="/coaching" element={<Coaching />} />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </main>
        <ScrollToTopButton />
      </div>
    </AuthContext.Provider>
  )
}

export default function App() {
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [emailConfirmed] = useState(() =>
    typeof window !== 'undefined' &&
    (window.location.hash.includes('type=signup') ||
     sessionStorage.getItem('quark_email_confirmed') === '1')
  )

  // When a user clicks the email-confirmation link, Supabase auto-creates a
  // session. We don't want to drop them straight into Quark — sign that
  // session out and reload to a clean state so they land on the sign-in page.
  useEffect(() => {
    if (window.location.hash.includes('type=signup')) {
      sessionStorage.setItem('quark_email_confirmed', '1')
      supabase.auth.signOut().then(() => {
        window.location.replace('/')
      })
    }
  }, [])

  const fetchProfile = async (u) => {
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('id', u.id)
      .maybeSingle()
    if (data) {
      setProfile(data)
    } else {
      const { data: np } = await supabase
        .from('users')
        .upsert({ id: u.id, email: u.email, name: u.email.split('@')[0], role: 'viewer' })
        .select()
        .maybeSingle()
      setProfile(np)
    }
    setLoading(false)
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      if (session?.user) fetchProfile(session.user)
      else setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchProfile(session.user)
        if (event === 'SIGNED_IN') {
          sessionStorage.removeItem('quark_email_confirmed')
          supabase.from('users').update({ last_login: new Date().toISOString() }).eq('id', session.user.id).then(({ error }) => {
            if (error) console.error('last_login update failed:', error.message)
            else console.log('last_login updated for', session.user.email)
          })
        }
      } else { setProfile(null); setLoading(false) }
    })
    return () => subscription.unsubscribe()
  }, [])

  const logout = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setProfile(null)
  }

  // Just confirmed their email via the link — force the sign-in page.
  if (emailConfirmed && !user) return <Login confirmed />

  if (loading) return (
    <div className="fullpage-loader">
      <DuckLoader />
    </div>
  )

  // Public routes — shown regardless of auth state
  // Also intercept when Supabase auto-signs in via recovery token
  const isRecovery = window.location.pathname === '/reset-password' ||
    window.location.hash.includes('type=recovery')
  if (isRecovery) return <ResetPassword />

  if (!user) return <Login />

  return <AppShell user={user} profile={profile} logout={logout} fetchProfile={fetchProfile} />
}
